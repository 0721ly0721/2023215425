//#include "main.h"
////#include "tim.h"
//#include "gpio.h"
////** Compare is the PWM setting 
////** range 0-100
//void PWM_GPIOB_5_SetCompare1(uint16_t Compare)
//{
//	uint16_t pulse = (htim3.Init.Period * Compare) / 100;
//	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulse);
//}

//void PWM_GPIOB_10_SetCompare1(uint16_t Compare)
//{
//	uint16_t pulse = (htim2.Init.Period * Compare) / 100;
//	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulse);
//}
//void PWM_GPIOB_11_SetCompare1(uint16_t Compare)
//{
//	uint16_t pulse = (htim2.Init.Period * Compare) / 100;
//	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulse);
//}
//void PWM_GPIOA_15_SetCompare1(uint16_t Compare)
//{
//	uint16_t pulse = (htim2.Init.Period * Compare) / 100;
//	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pulse);	
//}
